from pathlib import Path
import subprocess,json,hashlib,tarfile,io,shutil
root=Path('/workspace');w=root/'work/w5c-resume'
for repo in ['craft-gtm-mcp','craft-content-mcp']:
 src=root/repo;dst=w/'overlays'/repo;dst.mkdir(parents=True,exist_ok=True)
 raw=subprocess.check_output(['git','archive','HEAD'],cwd=src)
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(dst,filter='data')
 changes=json.loads((w/(repo+'-remote-files.json')).read_text())
 for f in changes['files']:
  data=f['content'].encode();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==f['sha'],f['path']
  p=dst/f['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 (dst/'node_modules').symlink_to(src/'node_modules',target_is_directory=True)
 # Apply only the two actual test files. Docs and production are not overlaid.
 test='tests/run40s-escape.test.mjs' if repo=='craft-gtm-mcp' else 'tests/run22-echo-gaps.test.mjs'
 for f in [test,'tests/helpers/cpu-budget.mjs']:
  p=dst/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src/f,p)
 print(repo,'overlay prepared')
